class Vehicle {
    func description() -> String { "A vehicle" }
}
class Car: Vehicle {
    override func description() -> String { "This is a car" }
}
class Bike: Vehicle {
    override func description() -> String { "This is a bike" }
}
let vehicles: [Vehicle] = [Car(), Bike(), Vehicle()]
for vehicle in vehicles { print(vehicle.description()) }
