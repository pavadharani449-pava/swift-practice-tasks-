enum BookStatus {
    case available
    case borrowed(by: String, dueIns: Int)
    case reserved(for: String)
    var label: String {
        switch self {
        case .available: return "Available"
        case .borrowed(let name, let days): return "Borrowed by \(name), due in \(days) days"
        case .reserved(let name): return "Reserved for \(name)"
        }
    }
}
struct Book { var title: String; var status: BookStatus = .available }
class Member { var name: String; var borrowedBooks: [String] = []; init(name: String) { self.name = name } }
var book1 = Book(title: "Swift", status: .available)
var book2 = book1
book2.status = .borrowed(by: "Anu", dueIns: 3)
print(book1.title, book1.status.label)
print(book2.title, book2.status.label) // Struct copies are independent.
let member1 = Member(name: "Anu")
let member2 = member1
member2.name = "Bala"
print(member1.name, member2.name) // Both class variables share one object.
