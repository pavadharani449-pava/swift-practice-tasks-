enum Grade: String { case A, B, C, F }
struct Student {
    var name: String
    var marks: Int
    var grade: Grade { switch marks { case 90...100: .A; case 75..<90: .B; case 50..<75: .C; default: .F } }
}
class School {
    var students: [Student] = []
    func add(_ student: Student) { students.append(student) }
    func printReport() {
        for student in students.sorted(by: { $0.marks > $1.marks }) {
            print("\(student.name): \(student.marks), Grade \(student.grade.rawValue)")
        }
    }
}
let school = School()
school.add(Student(name: "Anu", marks: 92))
school.add(Student(name: "Bala", marks: 68))
school.add(Student(name: "Chitra", marks: 81))
school.printReport()
