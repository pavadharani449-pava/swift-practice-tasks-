struct ValueItem { var value: Int }
class ReferenceItem { var value: Int; init(value: Int) { self.value = value } }
var originalStruct = ValueItem(value: 10)
var copiedStruct = originalStruct
copiedStruct.value = 20
print("Struct original:", originalStruct.value) // Struct copy is independent.
let originalClass = ReferenceItem(value: 10)
let copiedClass = originalClass
copiedClass.value = 20
print("Class original:", originalClass.value) // Both variables refer to the same object.
