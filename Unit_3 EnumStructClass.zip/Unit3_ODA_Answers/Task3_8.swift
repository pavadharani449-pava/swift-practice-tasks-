enum Planet: CaseIterable {
    case mercury, venus, earth, mars, jupiter, saturn, uranus, neptune
    var orderFromSun: Int { Planet.allCases.firstIndex(of: self)! + 1 }
}
for planet in Planet.allCases { print(planet, planet.orderFromSun) }
