class Person {
    var name: String
    var age: Int
    init(name: String, age: Int) { self.name = name; self.age = age }
    func introduce() { print("Hi, I am \(name), age \(age).") }
}
let person = Person(name: "Anu", age: 20)
person.introduce()
