struct Counter {
    var value = 0
    mutating func increment() { value += 1 }
}
class Box {
    var value = 0
    func increment() { value += 1 }
}
var c = Counter() // Fix: use var, because a struct value must be mutable to call mutating methods.
c.increment()
print(c.value)
let b = Box()
b.increment() // A class constant can change its object's properties.
print(b.value)
let anotherBox = b
print(b === anotherBox) // true: both refer to the same object.
