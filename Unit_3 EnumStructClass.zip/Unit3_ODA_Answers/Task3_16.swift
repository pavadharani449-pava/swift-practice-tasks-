struct MathHelper {
    static func square(_ number: Int) -> Int { number * number }
}
class Counter {
    static var instancesCreated = 0
    init() { Counter.instancesCreated += 1 }
}
print(MathHelper.square(5))
let c1 = Counter()
let c2 = Counter()
print("Instances:", Counter.instancesCreated)
