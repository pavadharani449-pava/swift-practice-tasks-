struct Student {
    var name: String
    var rollNumber: Int
    var marks: Int
    func isPassed() -> Bool { return marks >= 40 }
}
let student = Student(name: "Anu", rollNumber: 1, marks: 85)
print(student.isPassed())
