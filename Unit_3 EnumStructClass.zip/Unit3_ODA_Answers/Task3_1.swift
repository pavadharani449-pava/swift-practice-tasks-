enum Direction { case north, south, east, west }
for direction in [Direction.north, .south, .east, .west] {
    switch direction {
    case .north: print("Go North")
    case .south: print("Go South")
    case .east: print("Go East")
    case .west: print("Go West")
    }
}
