// Print numbers 1 to 10
for number in 1...10 {
    print(number)
}
