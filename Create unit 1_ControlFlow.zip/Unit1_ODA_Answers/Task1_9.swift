// Largest of three numbers using nested if
let a = 10, b = 25, c = 18
if a > b {
    if a > c { print(a) } else { print(c) }
} else {
    if b > c { print(b) } else { print(c) }
}
