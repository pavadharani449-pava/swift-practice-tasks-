UNIT 1 ODA ANSWERS - SWIFT

Contains Swift solutions for Unit 1 tasks 1.1-1.18 and all three additional tasks from the provided practice document. Open each .swift file in Xcode Playgrounds or run with Swift.
