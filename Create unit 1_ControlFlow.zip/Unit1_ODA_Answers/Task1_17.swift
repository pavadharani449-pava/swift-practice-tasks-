// Check palindrome and Armstrong number (3-digit example)
let number = 121
var temp = number
var reversed = 0
while temp > 0 {
    reversed = reversed * 10 + temp % 10
    temp /= 10
}
print("Palindrome: \(number == reversed)")

let armstrongNumber = 153
var value = armstrongNumber
var total = 0
while value > 0 {
    let digit = value % 10
    total += digit * digit * digit
    value /= 10
}
print("Armstrong: \(total == armstrongNumber)")
