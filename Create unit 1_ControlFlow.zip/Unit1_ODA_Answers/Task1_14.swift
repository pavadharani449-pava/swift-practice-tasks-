// Simple calculator using switch
let a = 12.0
let b = 3.0
let operation = "/"
switch operation {
case "+": print(a + b)
case "-": print(a - b)
case "*": print(a * b)
case "/":
    if b != 0 { print(a / b) } else { print("Cannot divide by zero") }
default: print("Invalid operator")
}
