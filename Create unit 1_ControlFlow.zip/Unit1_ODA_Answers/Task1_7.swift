// Larger number using ternary operator
let a = 15
let b = 20
let larger = a > b ? a : b
print("Larger number: \(larger)")
