// Right-angled triangle; skip even rows with continue
let n = 5
for row in 1...n {
    if row % 2 == 0 { continue }
    print(String(repeating: "*", count: row))
}
