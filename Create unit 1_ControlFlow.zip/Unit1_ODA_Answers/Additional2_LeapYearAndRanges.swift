// Boolean expressions without if statements
for year in [1900, 2000, 2024, 2026] {
    let isLeapYear = (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0)
    print("\(year): \(isLeapYear)")
}
let number = 50
print("Between 1 and 100: \((1...100).contains(number))")
let evenNotMultipleOf10 = number % 2 == 0 && number % 10 != 0
print("Even and not multiple of 10: \(evenNotMultipleOf10)")
let nickname: String? = nil
print(nickname ?? "Guest")
