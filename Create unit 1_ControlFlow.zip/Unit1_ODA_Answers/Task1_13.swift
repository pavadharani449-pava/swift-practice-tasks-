// Check a number and print primes from 1 to 50
func isPrime(_ number: Int) -> Bool {
    if number < 2 { return false }
    if number == 2 { return true }
    for i in 2...Int(Double(number).squareRoot()) {
        if number % i == 0 { return false }
    }
    return true
}
let number = 17
print("\(number) is prime: \(isPrime(number))")
for value in 1...50 {
    if isPrime(value) { print(value) }
}
