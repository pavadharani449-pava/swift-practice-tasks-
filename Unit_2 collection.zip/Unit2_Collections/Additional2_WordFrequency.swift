let sentence = "swift is fun and swift is fast"
let words = sentence.split(separator: " ").map(String.init)
var frequency: [String: Int] = [:]
for word in words { frequency[word, default: 0] += 1 }
print("Word count:", words.count)
print("Unique words:", Set(words).sorted())
for word in frequency.keys.sorted() { print("\(word): \(frequency[word]!)") }
let ranked = frequency.sorted { if $0.value == $1.value { return $0.key < $1.key }; return $0.value > $1.value }
print("Ranked by frequency:")
for (word, count) in ranked { print("\(word): \(count)") }
