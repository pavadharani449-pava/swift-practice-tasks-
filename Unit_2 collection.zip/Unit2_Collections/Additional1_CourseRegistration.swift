var subjects = ["Swift", "UIKit", "SwiftUI"]
subjects.append("Networking")
subjects.insert("Testing", at: 1)
if let index = subjects.firstIndex(of: "UIKit") { subjects.remove(at: index) }
print("Sorted subjects:", subjects.sorted())

var registered: Set<String> = ["Anu", "Bala"]
registered.insert("Anu")
registered.insert("Chitra")
print("Registered students:", registered)
print("Unique count:", registered.count)

var marks = ["Anu": 85, "Bala": 78, "Chitra": 92]
marks["Dev"] = 88
marks["Bala"] = 82
print("Missing student mark:", marks["Esha"] as Any)
for name in marks.keys.sorted() { print("\(name): \(marks[name]!)") }
if let top = marks.max(by: { $0.value < $1.value }) { print("Highest mark: \(top.key) - \(top.value)") }
