let evenNumbers = (1...20).filter { $0 % 2 == 0 }
let squares = evenNumbers.map { $0 * $0 }
let sumOfSquares = squares.reduce(0, +)
print("Even numbers:", evenNumbers)
print("Squares:", squares)
print("Sum of squares:", sumOfSquares)
