let marks = ["Anu": 90, "Bala": 85, "Chitra": 95]
let searchName = "Bala"
if let mark = marks[searchName] { print("\(searchName): \(mark)") }
else { print("Not found") }
