let students = ["Anu": 90, "Bala": 85, "Chitra": 95, "Dev": 78, "Esha": 88]
let sortedStudents = students.sorted { if $0.value == $1.value { return $0.key < $1.key }; return $0.value > $1.value }
for (name, mark) in sortedStudents.prefix(3) { print("\(name): \(mark)") }
