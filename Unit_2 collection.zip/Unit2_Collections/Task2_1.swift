// Create an array and print its details.
let numbers = [10, 20, 30, 40, 50]
print("Array:", numbers)
print("Count:", numbers.count)
if let first = numbers.first, let last = numbers.last {
    print("First:", first)
    print("Last:", last)
}
