let prices: [String: Double] = ["Book": 150.0, "Pen": 20.0, "Bag": 750.0, "Bottle": 100.0]
let itemsBought = ["Book", "Pen", "Bag"]
var total = 0.0
for item in itemsBought {
    if let price = prices[item] { total += price; print("\(item): ₹\(price)") }
    else { print("Price not found for \(item)") }
}
print("Total bill: ₹\(total)")
