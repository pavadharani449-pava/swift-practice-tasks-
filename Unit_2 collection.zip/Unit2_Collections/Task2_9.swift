let numbers = [1, 2, 3, 4, 5]
var reversedNumbers: [Int] = []
for number in numbers { reversedNumbers.insert(number, at: 0) }
print(reversedNumbers)
