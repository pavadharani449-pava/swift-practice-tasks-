let swiftClub: Set<String> = ["Anu", "Ben", "Chitra", "Dev"]
let uiClub: Set<String> = ["Chitra", "Dev", "Esha"]
print("In both clubs:", swiftClub.intersection(uiClub).sorted())
print("Only Swift club:", swiftClub.subtracting(uiClub).sorted())
print("Everyone:", swiftClub.union(uiClub).sorted())
print("Exactly one club:", swiftClub.symmetricDifference(uiClub).sorted())

let numbers = [3, 1, 3, 2, 1, 4]
var unique: [Int] = []
for number in numbers { if !unique.contains(number) { unique.append(number) } }
print("Without duplicates, original order:", unique)
