var fruits = ["Apple", "Mango", "Banana", "Orange", "Grapes"]
fruits.append("Pineapple")
print("After append:", fruits)
fruits.insert("Watermelon", at: 0)
print("After insert:", fruits)
if let index = fruits.firstIndex(of: "Banana") { fruits.remove(at: index) }
print("After remove:", fruits)
