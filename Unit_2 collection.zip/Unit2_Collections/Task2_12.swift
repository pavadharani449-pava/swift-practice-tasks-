let setA: Set<Int> = [1, 2, 3, 4]
let setB: Set<Int> = [3, 4, 5, 6]
print("Union:", setA.union(setB))
print("Intersection:", setA.intersection(setB))
print("Subtracting A - B:", setA.subtracting(setB))
print("Symmetric difference:", setA.symmetricDifference(setB))
