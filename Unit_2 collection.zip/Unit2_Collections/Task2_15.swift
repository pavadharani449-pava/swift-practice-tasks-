let numbers = [10, 5, 20, 20, 8, 15]
let uniqueSorted = Array(Set(numbers)).sorted(by: >)
if uniqueSorted.count >= 2 { print("Second largest:", uniqueSorted[1]) }
else { print("No second largest element") }
