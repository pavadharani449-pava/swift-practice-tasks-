let numbers: Set<Int> = [1, 2, 2, 3, 4, 4, 5]
print("Set:", numbers)
print("Count (duplicates removed):", numbers.count)
