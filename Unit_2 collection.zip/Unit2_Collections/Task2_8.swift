let numbers = [5, 10, 15, 20, 25]
let searchValue = 15
if numbers.contains(searchValue) { print("Value exists") }
else { print("Value not found") }
