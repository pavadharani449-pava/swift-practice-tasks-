let numbers = [3, 1, 3, 2, 1, 4, 2]
var uniqueNumbers: [Int] = []
for number in numbers {
    if !uniqueNumbers.contains(number) { uniqueNumbers.append(number) }
}
print(uniqueNumbers)
