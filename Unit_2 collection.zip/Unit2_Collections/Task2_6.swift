let students = ["Anu": 90, "Bala": 85, "Chitra": 95, "Dev": 78, "Esha": 88]
for (name, mark) in students { print("\(name): \(mark)") }
