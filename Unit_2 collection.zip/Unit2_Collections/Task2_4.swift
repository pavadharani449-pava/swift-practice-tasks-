let numbers = [34, 12, 89, 5, 67]
if var largest = numbers.first, var smallest = numbers.first {
    for number in numbers {
        if number > largest { largest = number }
        if number < smallest { smallest = number }
    }
    print("Maximum:", largest)
    print("Minimum:", smallest)
}
