let names = ["Anu", "Arun", "Bala", "Chitra", "Charan", "Dev"]
var grouped: [Character: [String]] = [:]
for name in names {
    if let first = name.first { grouped[first, default: []].append(name) }
}
for letter in grouped.keys.sorted() { print("\(letter): \(grouped[letter]!)") }
